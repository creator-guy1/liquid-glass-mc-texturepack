LIQUID GLASS - GUI resource pack for Minecraft: Java Edition
============================================================
Frosted, translucent "liquid glass" interface inspired by Apple's Liquid Glass design language: glass bodies that
get denser towards the edges (like a lens), a thin specular rim lit from the upper-left with a softer
counter-highlight on the lower-right, a faint chromatic fringe and soft inner bevel glow.

What is restyled
 - Menu buttons (normal / hover / disabled), sliders + handles, text fields, tick boxes, tabs, scrollbars
 - Header / footer separator lines (menu backgrounds are the original vanilla ones)
 - Hotbar, selection highlight, off-hand slots, experience bar
 - Tooltips and toasts (advancements, recipes, system)
 - Creative inventory: item tabs, search tab, survival-inventory tab, tab buttons and scrollbar
 - Inventories: player inventory, chests / ender chests / barrels (generic_54), crafting table, furnace, blast furnace,
   smoker (incl. flame + arrow progress), dispenser / dropper, hopper, shulker box
 Everything not listed keeps the vanilla look (e.g. anvil, enchanting table, brewing stand, villager trading).

Install: put the zip into .minecraft/resourcepacks (or drag it onto the game window) and enable it under
Options > Resource Packs. Works best with the "Derivative AI" shader pack but needs no shaders.

Tips
 - Looks crispest at GUI Scale 3 or 4 (textures are 4x resolution).
 - Container panels are bright frosted glass so the vanilla dark-grey labels stay readable.

All textures are generated procedurally; no Mojang or third-party assets are included.
